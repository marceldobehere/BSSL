﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BSSL___Interpreter
{
    class Program
    {
        static string alldata;
        static int index;
        static Dictionary<string, int> JumpPoints;
        static Dictionary<string, string> Variables;
        static void Main()
        {
            index = 0;
            alldata = "";
            JumpPoints = new Dictionary<string, int>();
            Variables = new Dictionary<string, string>();

            string[] args = System.Environment.GetCommandLineArgs();
            if (args.Length > 1)
            {
                if (System.IO.File.Exists(args[1]))
                {
                    string filePath = args[1];
                    //Console.WriteLine($"Opened with File: {filePath}");
                    StringBuilder temp = new StringBuilder();
                    System.IO.StreamReader reader = new System.IO.StreamReader(filePath);
                    while (!reader.EndOfStream)
                    {
                        temp.Append(reader.ReadLine() + "\n");
                    }
                    reader.Close();
                    Print(temp.ToString(), true, false);
                }
                else
                {
                    Console.WriteLine("ERROR: File does not exist!");
                }
            }
            else
            {
                Console.WriteLine("ERROR: Not opened with any valid Files!");
            }



            Console.WriteLine("\n-----------------------------------\nEnd.");
            //Console.WriteLine("-----------------------------------\nAll Data:");
            //Console.WriteLine(alldata);
            //Console.WriteLine("-----------------------------------");
            Console.ReadLine();
        }


        static string RunCommand(string data, bool output)
        {

            //Console.WriteLine($"<{data}>");
            //Console.WriteLine("!<" + Print(data, false, true) + "> ");
            string outputtext = "";
            try
            {
                //Console.WriteLine("1A");
                string data2 = Print(data, false, true);
                //Console.WriteLine("2A");
                string[] cmd = data2.Split(' ');
                switch (cmd[0])
                {
                    case "":
                        break;

                    case "jump_def":
                        //Console.WriteLine($"<Adding Jumppoint {cmd[1]} to {index} >");
                        JumpPoints.Add(cmd[1], index);
                        break;
                    case "jump_to":
                        //Console.WriteLine($"<Jumping to {cmd[1]} ({JumpPoints[cmd[1]]})>");
                        index = JumpPoints[cmd[1]];
                        break;


                    case "new":
                        {
                            string temp = cmd[2];
                            for (int i = 3; i < cmd.Length; i++)
                            {
                                temp += " " + cmd[i];
                            }
                            Variables.Add(cmd[1], temp);
                        }
                        break;

                    case "read":
                        Variables[cmd[1]] = Console.ReadLine();
                        break;

                    case "print":
                        outputtext += Print(Variables[cmd[1]], output, true);
                        break;

                    //math0 (variable name)1 (operator)2 (amount)3 (output variable)4
                    case "math":
                        if (cmd[2] == "+")
                        {
                            Variables[cmd[4]] = (float.Parse(Variables[cmd[1]], NumberStyles.Float, CultureInfo.InvariantCulture) + float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture);
                        }
                        if (cmd[2] == "-")
                        {
                            Variables[cmd[4]] = (float.Parse(Variables[cmd[1]], NumberStyles.Float, CultureInfo.InvariantCulture) - float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture);
                        }
                        if (cmd[2] == "*")
                        {
                            Variables[cmd[4]] = (float.Parse(Variables[cmd[1]], NumberStyles.Float, CultureInfo.InvariantCulture) * float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture);
                        }
                        if (cmd[2] == "/")
                        {
                            Variables[cmd[4]] = (float.Parse(Variables[cmd[1]], NumberStyles.Float, CultureInfo.InvariantCulture) / float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture);
                        }
                        if (cmd[2] == "%")
                        {
                            Variables[cmd[4]] = (float.Parse(Variables[cmd[1]], NumberStyles.Float, CultureInfo.InvariantCulture) % float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture);
                        }
                        break;
                    //if (variablename)1 (operator)2 (variablename)3 (jumppoint)4
                    case "if_jump":
                        if (cmd[2] == "==")
                        {
                            if (Variables[cmd[1]] == Variables[cmd[3]])
                            {
                                index = JumpPoints[cmd[4]];
                            }
                        }
                        if (cmd[2] == "!=")
                        {
                            if (Variables[cmd[1]] != Variables[cmd[3]])
                            {
                                index = JumpPoints[cmd[4]];
                            }
                        }

                        if (cmd[2] == ">")
                        {
                            if (float.Parse(Variables[cmd[1]], NumberStyles.Float, CultureInfo.InvariantCulture) > float.Parse(Variables[cmd[3]], NumberStyles.Float, CultureInfo.InvariantCulture))
                            {
                                index = JumpPoints[cmd[4]];
                            }
                        }

                        if (cmd[2] == ">=")
                        {
                            if (float.Parse(Variables[cmd[1]], NumberStyles.Float, CultureInfo.InvariantCulture) >= float.Parse(Variables[cmd[3]], NumberStyles.Float, CultureInfo.InvariantCulture))
                            {
                                index = JumpPoints[cmd[4]];
                            }
                        }

                        if (cmd[2] == "<")
                        {
                            if (float.Parse(Variables[cmd[1]], NumberStyles.Float, CultureInfo.InvariantCulture) < float.Parse(Variables[cmd[3]], NumberStyles.Float, CultureInfo.InvariantCulture))
                            {
                                index = JumpPoints[cmd[4]];
                            }
                        }
                        if (cmd[2] == "<=")
                        {
                            if (float.Parse(Variables[cmd[1]], NumberStyles.Float, CultureInfo.InvariantCulture) <= float.Parse(Variables[cmd[3]], NumberStyles.Float, CultureInfo.InvariantCulture))
                            {
                                index = JumpPoints[cmd[4]];
                            }
                        }
                        break;
                }
            }
            catch
            {
                Console.WriteLine("!!!!ERROR APPEARED LOL!!!!!");
            }
            //Console.WriteLine("3A");
            return outputtext;
        }


        static char GetNextChar(string data, bool increase, bool add)
        {
            char nextchar;
            
            if (index >= 0)
            {
                nextchar = data[index];
            }
            else
            {
                nextchar = alldata[alldata.Length + index];
            }
            if (increase)
            {
                index++;
            }
            if (add)
            {
                alldata += nextchar;
            }

            return nextchar;
        }


        static string Print(string data, bool output, bool justprint)
        {
            int tempindex = index;
            if (justprint)
            {
                index = 0;
            }
            //Console.WriteLine($"O -<{index}, {data}, {output}, {justprint}>");
            string outtext = "";
            //int subindex = 0;
            for (; index < data.Length;)
            {
                char nextchar = GetNextChar(data, true, justprint);
                //Console.WriteLine($"- <{index}, {nextchar}>");
                if (nextchar == '\\')
                {
                    char nextchar2 = GetNextChar(data, true, justprint);
                    if (nextchar2 == '\\')
                    {
                        if (output)
                        {
                            Console.Write('\\');
                        }
                        outtext += '\\';
                    }
                    else if (nextchar2 == 'n')
                    {
                        if (output)
                        {
                            Console.Write('\n');
                        }
                        outtext += '\n';
                    }
                    else if (nextchar2 == 'i')
                    {
                        GetNextChar(data, true, justprint);
                    }
                    else if (nextchar2 == '[')
                    {
                        char temp1 = ' ';
                        char temp2 = ' ';

                        string commanddata = "";
                        int temp = 1;
                        while (temp > 0)
                        {
                            temp1 = GetNextChar(data, true, justprint);
                            commanddata += temp1;
                            if (temp1 == '\\')
                            {
                                temp2 = GetNextChar(data, true, justprint);
                                commanddata += temp2;
                                if (temp2 == ']')
                                {
                                    temp--;
                                }
                                if (temp2 == '[')
                                {
                                    temp++;
                                }
                            }
                        }
                        commanddata = commanddata.Remove(commanddata.Length - 2, 2);
                        //Console.WriteLine($"<running command: {commanddata}>");
                        outtext += RunCommand(commanddata, output);
                    }
                    else if (nextchar2 == '<')
                    {
                        char temp1 = ' ';
                        char temp2 = ' ';


                        while (temp2 != '>')
                        {
                            temp1 = GetNextChar(data, true, justprint);
                            if (temp1 == '\\')
                            {
                                temp2 = GetNextChar(data, true, justprint);
                            }
                        }

                    }
                }
                else
                {
                    if (output)
                    {
                        Console.Write(nextchar);
                    }
                    outtext += nextchar;
                }
            }
            if (justprint)
            {
                index = tempindex; 
            }

            return outtext;
        }

    }
}
