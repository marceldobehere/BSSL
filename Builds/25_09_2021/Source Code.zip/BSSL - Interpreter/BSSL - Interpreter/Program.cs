﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BSSL___Interpreter
{
    class Program
    {
        static string alldata;
        static int index;
        static bool ignore_errors;
        static Dictionary<string, int> JumpPoints;
        static Dictionary<string, string> Variables;


        static string ReadFile(string filename)
        {
            StringBuilder temp = new StringBuilder();
            System.IO.StreamReader reader = new System.IO.StreamReader(filename);
            while (!reader.EndOfStream)
            {
                temp.Append(reader.ReadLine() + "\n");
            }
            reader.Close();
            return temp.ToString();
        }

        static void Main()
        {
            ignore_errors = false;
            index = 0;
            alldata = "";
            JumpPoints = new Dictionary<string, int>();
            Variables = new Dictionary<string, string>();

            string[] args = System.Environment.GetCommandLineArgs();
            if (args.Length > 1)
            {
                if (System.IO.File.Exists(args[1]))
                {
                    string filePath = args[1];
                    //Console.WriteLine($"Opened with File: {filePath}");

                    Print(ReadFile(filePath), true, false, true);
                }
                else
                {
                    Console.WriteLine("ERROR: File does not exist!");
                }
            }
            else
            {
                Console.WriteLine("ERROR: Not opened with any valid Files!");
            }



            Console.WriteLine("\n-----------------------------------\nEnd.");
            //Console.WriteLine("-----------------------------------\nAll Printed Data:");
            //Console.WriteLine(alldata);
            //Console.WriteLine("-----------------------------------");
            Console.ReadLine();
        }


        static string RunCommand(string data, bool output)
        {

            //Console.WriteLine($"<{data}>");
            //Console.WriteLine("!<" + Print(data, false, true) + "> ");
            string outputtext = "";
            try
            {
                //Console.WriteLine("1A");
                string data2 = Print(data, false, true, true);
                //Console.WriteLine("2A");
                string[] cmd = data2.Split(' ');
                switch (cmd[0])
                {
                    case "":
                        break;

                    case "jump_def":
                        //Console.WriteLine($"<Adding Jumppoint {cmd[1]} to {index} >");
                        if (!JumpPoints.ContainsKey(cmd[1]))
                        {
                            JumpPoints.Add(cmd[1], index);
                        }
                        else
                        {
                            JumpPoints[cmd[1]] = index;
                        }

                        break;
                    case "jump_to":
                        //Console.WriteLine($"<Jumping to {cmd[1]} ({JumpPoints[cmd[1]]})>");
                        index = JumpPoints[cmd[1]];
                        break;


                    case "new":
                        {
                            string temp = cmd[2];
                            for (int i = 3; i < cmd.Length; i++)
                            {
                                temp += " " + cmd[i];
                            }
                            Variables.Add(cmd[1], temp);
                        }
                        break;

                    case "read":
                        {
                            string temp = Console.ReadLine();
                            if (temp.Length == 0)
                            {
                                temp = " ";
                            }
                            Variables[cmd[1]] = temp;
                        }

                        break;

                    //char_at0 (variablename)1 (value)2 (variablename)3
                    case "str_char_at":
                        outputtext += "" + Variables[cmd[1]][int.Parse(cmd[2])];
                        break;

                    case "str_get_length":
                        outputtext += "" + Variables[cmd[1]].Length;
                        break;

                    //str_substring0 (variablename)1 (startindex)2 (length)3 (variablename)4
                    case "str_substring":
                        outputtext += Variables[cmd[1]].Substring(int.Parse(cmd[2]), int.Parse(cmd[3]));
                        break;

                    //str_index_of (variablename) (value)
                    case "str_index_of":
                        outputtext += Variables[cmd[1]].IndexOf(cmd[2]);
                        break;
                    //str_replace (variablename) (value) (value)
                    case "str_replace":
                        outputtext += Variables[cmd[1]].Replace(cmd[2], cmd[3]);
                        break;

                    //str_contains (variablename) (value)
                    case "str_contains":
                        if (Variables[cmd[1]].Contains(cmd[2]))
                        {
                            outputtext += Print("true", output, true, true);
                        }
                        else
                        {
                            outputtext += Print("false", output, true, true);
                        }
                        break;

                    case "set":
                        Variables[cmd[1]] = cmd[2];
                        break;

                    case "color_back":
                        Console.BackgroundColor = (ConsoleColor)int.Parse(cmd[1]);
                        break;
                    case "color_front":
                        Console.ForegroundColor = (ConsoleColor)int.Parse(cmd[1]);
                        break;
                    case "cls":
                        Console.Clear();
                        break;

                    case "print":
                        outputtext += Print(Variables[cmd[1]], output, true, true);
                        break;

                    case "print_file":
                        outputtext += Print(ReadFile(Variables[cmd[1]]), output, true, true);
                        break;

                    case "remove_commands":
                        Variables[cmd[1]] = RemoveCommands(Variables[cmd[1]]);
                        break;

                    //errors_ignore
                    case "errors_ignore":
                        ignore_errors = true;
                        break;
                    case "errors_unignore":
                        ignore_errors = false;
                        break;

                    //math2-0 (operator {sin, cos, tan, sqrt, floor, ceiling})-1 (amount)-2
                    case "math2":
                        //Console.WriteLine($"{cmd[1]} {cmd[2]} {cmd[3]}");
                        if (cmd[1] == "default")
                        {
                            outputtext += Print((float.Parse(cmd[2], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }

                        if (cmd[1] == "sqrt")
                        {
                            outputtext += Print(Math.Sqrt(float.Parse(cmd[2], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        if (cmd[1] == "floor")
                        {
                            outputtext += Print(Math.Floor(float.Parse(cmd[2], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        if (cmd[1] == "ceiling")
                        {
                            outputtext += Print(Math.Ceiling(float.Parse(cmd[2], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }

                        if (cmd[1] == "sin")
                        {
                            outputtext += Print(Math.Sin(float.Parse(cmd[2], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        if (cmd[1] == "cos")
                        {
                            outputtext += Print(Math.Cos(float.Parse(cmd[2], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        if (cmd[1] == "tan")
                        {
                            outputtext += Print(Math.Tan(float.Parse(cmd[2], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        if (cmd[1] == "asin")
                        {
                            outputtext += Print(Math.Asin(float.Parse(cmd[2], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        if (cmd[1] == "acos")
                        {
                            outputtext += Print(Math.Acos(float.Parse(cmd[2], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        if (cmd[1] == "atan")
                        {
                            outputtext += Print(Math.Atan(float.Parse(cmd[2], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }


                        break;


                    //math0 (variable name)1 (operator)2 (amount)3 
                    case "math":
                        //Console.WriteLine($"{cmd[1]} {cmd[2]} {cmd[3]}");
                        if (cmd[2] == "+")
                        {
                            outputtext += Print((float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) + float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        if (cmd[2] == "-")
                        {
                            outputtext += Print((float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) - float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        if (cmd[2] == "*")
                        {
                            outputtext += Print((float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) * float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        if (cmd[2] == "/")
                        {
                            outputtext += Print((float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) / float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        if (cmd[2] == "%")
                        {
                            outputtext += Print((float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) % float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        if (cmd[2] == "^")
                        {
                            outputtext += Print(Math.Pow(float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture), float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture)).ToString(CultureInfo.InvariantCulture), output, true, true);
                        }
                        break;
                    //if (variablename)1 (operator)2 (variablename)3 (jumppoint)4
                    case "if_jump":
                        if (cmd[2] == "==")
                        {
                            if (cmd[1] == cmd[3])
                            {
                                index = JumpPoints[cmd[4]];
                            }
                        }
                        if (cmd[2] == "!=")
                        {
                            if (cmd[1] != cmd[3])
                            {
                                index = JumpPoints[cmd[4]];
                            }
                        }

                        if (cmd[2] == ">")
                        {
                            if (float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) > float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture))
                            {
                                index = JumpPoints[cmd[4]];
                            }
                        }

                        if (cmd[2] == ">=")
                        {
                            if (float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) >= float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture))
                            {
                                index = JumpPoints[cmd[4]];
                            }
                        }

                        if (cmd[2] == "<")
                        {
                            if (float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) < float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture))
                            {
                                index = JumpPoints[cmd[4]];
                            }
                        }
                        if (cmd[2] == "<=")
                        {
                            if (float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) <= float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture))
                            {
                                index = JumpPoints[cmd[4]];
                            }
                        }
                        break;

                    //if (variablename)1 (operator)2 (variablename)3 variablename)4
                    case "if_print":
                        {
                            bool execute = false;
                            if (cmd[2] == "==")
                            {
                                if (cmd[1] == cmd[3])
                                {
                                    execute = true;
                                }
                            }
                            if (cmd[2] == "!=")
                            {
                                if (cmd[1] != cmd[3])
                                {
                                    execute = true;
                                }
                            }

                            if (cmd[2] == ">")
                            {
                                if (float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) > float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture))
                                {
                                    execute = true;
                                }
                            }

                            if (cmd[2] == ">=")
                            {
                                if (float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) >= float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture))
                                {
                                    execute = true;
                                }
                            }

                            if (cmd[2] == "<")
                            {
                                if (float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) < float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture))
                                {
                                    execute = true;
                                }
                            }
                            if (cmd[2] == "<=")
                            {
                                if (float.Parse(cmd[1], NumberStyles.Float, CultureInfo.InvariantCulture) <= float.Parse(cmd[3], NumberStyles.Float, CultureInfo.InvariantCulture))
                                {
                                    execute = true;
                                }
                            }

                            if (execute)
                            {
                                outputtext += Print(Variables[cmd[4]], output, true, true);
                            }
                        }

                        break;
                }
            }
            catch
            {
                if (!ignore_errors)
                {
                    Console.Write($"!!!!ERROR APPEARED LOL!!!!! Command: {data} - (");
                    try
                    {
                        Console.Write(Print(data, false, true, true));
                    }
                    catch
                    {
                        Console.Write(" ");
                    }
                    Console.WriteLine(") - Go fix that i guess lol.");
                }
            }
            //Console.WriteLine("3A");
            return outputtext;
        }

        static string RemoveCommands(string data)
        {
            if (data.Length > 0)
            {
                if (data[data.Length - 1] == '\\')
                {
                    if (data.Length > 1)
                    {
                        if (data[data.Length - 2] != '\\')
                        {
                            data += '\\';
                        }
                    }
                    else
                    {
                        data = " ";
                    }

                }

            }


            int tempindex = index;
            index = 0;

            string outtext = "";
            for (; index < data.Length;)
            {
                char nextchar = GetNextChar(data, true, true);

                if (nextchar == '\\')
                {
                    char nextchar2 = GetNextChar(data, true, true);

                    if (nextchar2 == '[')
                    {
                        char temp1 = ' ';
                        char temp2 = ' ';

                        string commanddata = "";
                        int temp = 1;
                        while (temp > 0 && index < data.Length)
                        {
                            temp1 = GetNextChar(data, true, true);
                            commanddata += temp1;
                            if (temp1 == '\\')
                            {
                                temp2 = GetNextChar(data, true, true);
                                commanddata += temp2;
                                if (temp2 == ']')
                                {
                                    temp--;
                                }
                                if (temp2 == '[')
                                {
                                    temp++;
                                }
                            }
                        }
                    }
                    else
                    {

                        outtext += $"{nextchar}{nextchar2}";
                    }
                }
                else
                {
                    outtext += nextchar;
                }
            }

            index = tempindex;


            if (outtext.Length == 0)
            {
                outtext = " ";
            }

            return outtext;
        }


        static char GetNextChar(string data, bool increase, bool add)
        {
            char nextchar;

            if (index >= 0)
            {
                nextchar = data[index];
            }
            else
            {
                nextchar = alldata[alldata.Length + index];
            }
            if (increase)
            {
                index++;
            }
            if (add)
            {
                alldata += nextchar;
            }

            return nextchar;
        }


        static string Print(string data, bool output, bool justprint, bool executecommands)
        {
            //Console.WriteLine("1<" + data + ">");
            if (data.Length > 0)
            {
                if (data[data.Length - 1] == '\\')
                {
                    if (data.Length > 1)
                    {
                        if (data[data.Length - 2] != '\\')
                        {
                            data += '\\';
                        }
                    }
                    else
                    {
                        data = " ";
                    }

                }

            }
            //Console.WriteLine("2<" + data + ">");
            int tempindex = index;
            if (justprint)
            {
                index = 0;
            }
            //Console.WriteLine($"O -<{index}, {data}, {output}, {justprint}>");
            string outtext = "";
            //int subindex = 0;
            for (; index < data.Length;)
            {
                char nextchar = GetNextChar(data, true, justprint);
                //Console.WriteLine($"- <{index}, {nextchar}>");

                if (nextchar == '\\')
                {
                    char nextchar2 = GetNextChar(data, true, justprint);
                    //Console.Write($"<{nextchar}{nextchar2}>");
                    if (nextchar2 == '\\')
                    {
                        if (output)
                        {
                            Console.Write('\\');
                        }
                        outtext += '\\';
                    }
                    else if (nextchar2 == 'n')
                    {
                        if (output)
                        {
                            Console.Write('\n');
                        }
                        outtext += '\n';
                    }
                    else if (nextchar2 == 'i')
                    {
                        GetNextChar(data, true, justprint);
                    }
                    else if (nextchar2 == '[')
                    {
                        char temp1 = ' ';
                        char temp2 = ' ';

                        string commanddata = "";
                        int temp = 1;
                        while (temp > 0 && index < data.Length)
                        {
                            temp1 = GetNextChar(data, true, justprint);
                            commanddata += temp1;
                            if (temp1 == '\\')
                            {
                                temp2 = GetNextChar(data, true, justprint);
                                commanddata += temp2;
                                if (temp2 == ']')
                                {
                                    temp--;
                                }
                                if (temp2 == '[')
                                {
                                    temp++;
                                }
                            }
                        }
                        commanddata = commanddata.Remove(commanddata.Length - 2, 2);
                        //Console.WriteLine($"<running command: {commanddata}>");
                        if (executecommands)
                        {
                            outtext += RunCommand(commanddata, output);
                        }
                    }
                    else if (nextchar2 == '<')
                    {
                        char temp1 = ' ';
                        char temp2 = ' ';



                        int temp = 1;
                        while (temp > 0 && index < data.Length)
                        {
                            temp1 = GetNextChar(data, true, justprint);
                            if (temp1 == '\\')
                            {
                                temp2 = GetNextChar(data, true, justprint);
                                if (temp2 == '>')
                                {
                                    temp--;
                                }
                                if (temp2 == '<')
                                {
                                    temp++;
                                }
                            }
                        }

                    }
                }
                else
                {
                    if (output)
                    {
                        Console.Write(nextchar);
                    }
                    outtext += nextchar;
                }
            }
            if (justprint)
            {
                index = tempindex;
            }

            if (outtext.Length == 0)
            {
                outtext = " ";
            }
            return outtext;
        }

    }
}
